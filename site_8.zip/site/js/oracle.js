/* ===== Carrousel de cartes : 3 visibles (gauche / centre / droite) ===== */
(() => {
  const root = document.getElementById('cartes');
  if (!root) return;
  const cards = [...root.querySelectorAll('.card')];
  const n = cards.length;
  let active = 0;
  function render() {
    cards.forEach((c, i) => {
      let rel = ((i - active) % n + n) % n;      // 0..n-1
      if (rel > n / 2) rel -= n;                  // -n/2..n/2
      c.dataset.rel = rel === 0 ? '0' : rel === -1 ? '-1' : rel === 1 ? '1' : rel < 0 ? 'out-l' : 'out-r';
    });
  }
  const go = d => { active = (active + d + n) % n; render(); };
  root.querySelector('.next').addEventListener('click', () => go(1));
  root.querySelector('.prev').addEventListener('click', () => go(-1));
  cards.forEach(c => c.addEventListener('click', () => {
    if (c.dataset.rel === '1') go(1); else if (c.dataset.rel === '-1') go(-1);
  }));
  render();
})();

/* ===== Slider des boîtes : 3 points = face avant / côté / dos (manuel) ===== */
(() => {
  const s = document.getElementById('slider');
  if (!s) return;
  const imgs = [...s.querySelectorAll(':scope > img')];
  const dots = [...s.querySelectorAll('.dots button')];
  let i = 0, timer;
  const show = k => {
    i = (k + imgs.length) % imgs.length;
    imgs.forEach((im, j) => im.classList.toggle('on', j === i));
    dots.forEach((d, j) => d.classList.toggle('on', j === i));
  };
  dots.forEach((d, j) => d.addEventListener('click', () => show(j)));   // changement manuel uniquement
})();

/* ===== Les 4 univers : Esotérisme / Décoration / Nourriture / Parfum =====
   Chaque bouton change la couleur de la bougie, du sac et du poster.
   Pour changer l'association, modifie data-theme dans oracle.html. */
(() => {
  const box = document.getElementById('themes');
  if (!box) return;
  const btns = [...box.querySelectorAll('button')];
  const set = t => {
    ['bougie', 'sac', 'poster'].forEach(k => {
      const el = document.getElementById('m-' + k);
      const src = `img/oracle/${t}-${k}.webp`;
      el.style.opacity = 0;
      setTimeout(() => { el.src = src; el.onload = () => el.style.opacity = 1; }, 200);
    });
    btns.forEach(b => b.classList.toggle('on', b.dataset.theme === t));
  };
  btns.forEach(b => b.addEventListener('click', () => { if (!b.classList.contains('on')) set(b.dataset.theme); }));
})();
