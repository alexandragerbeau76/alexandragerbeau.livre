/* Révélation nette : le fond reste flou ; là où la souris passe, la fleur devient nette,
   puis le flou revient doucement. Réglages ci-dessous. */
(() => {
  const cv = document.getElementById('reveal');
  const hero = document.querySelector('.hero');
  if (!cv || !hero || matchMedia('(prefers-reduced-motion: reduce)').matches) return;

  const BRUSH = 150;      // rayon du pinceau (en unités de la maquette, 1728 = largeur écran)
  const FADE_MS = 2200;   // durée avant que le flou revienne (mettre 1e9 pour garder la zone nette)
  const DPR = Math.min(window.devicePixelRatio || 1, 1.5);

  const ctx = cv.getContext('2d');
  const mask = document.createElement('canvas'), mctx = mask.getContext('2d');
  const img = new Image();
  let ready = false, W = 0, H = 0, last = null, lastMove = 0, running = false, prevT = 0;

  function size() {
    const r = hero.getBoundingClientRect();
    W = Math.round(r.width * DPR); H = Math.round(r.height * DPR);
    cv.width = mask.width = W; cv.height = mask.height = H;
  }
  function stamp(x, y) {
    const R = BRUSH * Math.min(W / 1728, H / 1080);
    const g = mctx.createRadialGradient(x, y, 0, x, y, R);
    g.addColorStop(0, 'rgba(0,0,0,.95)'); g.addColorStop(.5, 'rgba(0,0,0,.6)'); g.addColorStop(1, 'rgba(0,0,0,0)');
    mctx.fillStyle = g; mctx.beginPath(); mctx.arc(x, y, R, 0, 6.2832); mctx.fill();
  }
  function draw() {
    ctx.globalCompositeOperation = 'source-over';
    ctx.clearRect(0, 0, W, H);
    // même cadrage que le fond flou
    const s = Math.max(W / img.naturalWidth, H / img.naturalHeight);
    const iw = img.naturalWidth * s, ih = img.naturalHeight * s;
    ctx.drawImage(img, (W - iw) / 2, (H - ih) / 2, iw, ih);   // cover centré, comme le fond flou
    ctx.globalCompositeOperation = 'destination-in';
    ctx.drawImage(mask, 0, 0);
  }
  function loop(t) {
    const dt = Math.min(64, t - (prevT || t)); prevT = t;
    // le masque s'efface progressivement
    mctx.globalCompositeOperation = 'destination-out';
    mctx.fillStyle = 'rgba(0,0,0,' + Math.min(1, dt / FADE_MS * 2.2) + ')';
    mctx.fillRect(0, 0, W, H);
    mctx.globalCompositeOperation = 'source-over';
    draw();
    if (t - lastMove > FADE_MS + 600) {          // plus rien de visible : on arrête et on nettoie
      mctx.clearRect(0, 0, W, H); ctx.clearRect(0, 0, W, H); running = false; prevT = 0; return;
    }
    requestAnimationFrame(loop);
  }
  function move(e) {
    if (!ready) return;
    const r = hero.getBoundingClientRect();
    const x = (e.clientX - r.left) * DPR, y = (e.clientY - r.top) * DPR;
    if (last) {   // pinceau continu entre deux positions de souris
      const dx = x - last.x, dy = y - last.y, n = Math.max(1, Math.ceil(Math.hypot(dx, dy) / (20 * DPR)));
      for (let i = 1; i <= n; i++) stamp(last.x + dx * i / n, last.y + dy * i / n);
    } else stamp(x, y);
    last = { x, y }; lastMove = performance.now();
    if (!running) { running = true; requestAnimationFrame(loop); }
  }
  hero.addEventListener('pointermove', move);
  hero.addEventListener('pointerleave', () => { last = null; });
  window.addEventListener('resize', size);
  img.onload = () => { ready = true; size(); };
  img.src = cv.dataset.src;
})();
