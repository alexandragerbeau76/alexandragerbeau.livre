/* 1) Convertit style="left:44;top:17;width:273" -> calc(N * var(--u)) */
document.querySelectorAll('[style]').forEach(el => {
  const s = el.getAttribute('style');
  if (!/^\s*(left|top|width|height)\s*:\s*[\d.]+\s*(;|$)/.test(s)) return;
  const out = s.split(';').filter(Boolean).map(rule => {
    const [k, v] = rule.split(':').map(x => x.trim());
    return /^[\d.]+$/.test(v) ? `${k}:calc(${v} * var(--u))` : `${k}:${v}`;
  }).join(';');
  el.setAttribute('style', out);
});

/* 2) (ancien effet verre dépoli remplacé par la révélation nette : voir js/reveal.js) */

/* 3) Apparition douce des blocs de la partie blanche au scroll */
(() => {
  const els = document.querySelectorAll('.blanc .item');
  if (!('IntersectionObserver' in window)) return;
  els.forEach(el => el.classList.add('reveal'));
  const io = new IntersectionObserver(entries => entries.forEach(en => {
    if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); }
  }), { threshold: .12 });
  els.forEach(el => io.observe(el));
})();

/* 4) Glisser à la souris dans les zones de défilement manuel */
document.querySelectorAll('.dragscroll').forEach(box => {
  let down = false, sx = 0, sy = 0, sl = 0, st = 0, moved = false;
  box.addEventListener('pointerdown', e => {
    if (e.pointerType !== 'mouse' || e.button !== 0) return;       // tactile : défilement natif
    down = true; moved = false; sx = e.clientX; sy = e.clientY; sl = box.scrollLeft; st = box.scrollTop;
  });
  window.addEventListener('pointermove', e => {
    if (!down) return;
    const dx = e.clientX - sx, dy = e.clientY - sy;
    if (!moved && Math.abs(dx) + Math.abs(dy) > 4) { moved = true; box.classList.add('dragging'); }
    if (moved) { box.scrollLeft = sl - dx; box.scrollTop = st - dy; }
  });
  window.addEventListener('pointerup', () => { down = false; box.classList.remove('dragging'); });
});
