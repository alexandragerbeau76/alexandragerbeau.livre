/* Boutons Proposition 1 / Proposition 2 : chaque proposition a sa propre mise en page.
   Accès direct : stilla.html#proposition-2 */
(() => {
  const v1 = document.getElementById('view-1'), v2 = document.getElementById('view-2');
  function show(p, keepScroll) {
    v1.hidden = p !== 1; v2.hidden = p !== 2;
    if (!keepScroll) window.scrollTo({ top: 0, behavior: 'instant' });
    history.replaceState(null, '', p === 2 ? '#proposition-2' : location.pathname);
  }
  document.querySelectorAll('.tab').forEach(t =>
    t.addEventListener('click', () => { if (!t.classList.contains('on')) show(+t.dataset.p); }));
  if (location.hash === '#proposition-2') show(2, true);
})();
