/* Vidéo du logo Terpsis : rejouée à chaque ouverture de la page (y compris au retour arrière du navigateur) */
(() => {
  const v = document.getElementById('terpsis-anim');
  if (!v) return;
  const start = () => {
    v.currentTime = 0;
    const p = v.play();
    // si le navigateur bloque la lecture automatique : on montre directement l'image finale du logo
    if (p && p.catch) p.catch(() => { v.currentTime = Math.max(0, (v.duration || 8) - 0.05); });
  };
  if (v.readyState >= 2) start(); else v.addEventListener('loadeddata', start, { once: true });
  window.addEventListener('pageshow', e => { if (e.persisted) start(); });
})();
